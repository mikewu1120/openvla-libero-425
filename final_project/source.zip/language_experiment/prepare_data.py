"""Prepare a fixed, balanced three-task subset from official RLDS shards."""
import hashlib
import json
import os
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
OUT = ROOT / "datasets/language_experiment"
RAW = ROOT / "datasets/training_subset/raw"
REPO = "openvla/modified_libero_rlds"
REV = "6ce6aaaaabdbe590b1eef5cd29c0d33f14a08551"
PREFIX = "libero_spatial_no_noops/1.0.0"


def main():
    import numpy as np
    import tensorflow as tf
    from PIL import Image
    tf.config.threading.set_intra_op_parallelism_threads(2)
    tf.config.threading.set_inter_op_parallelism_threads(2)
    protocol = json.loads((ROOT / "language_experiment/protocol.json").read_text())
    tasks = {t["original"]: t["id"] for t in protocol["tasks"]}
    OUT.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(f"https://huggingface.co/api/datasets/{REPO}/tree/{REV}/{PREFIX}", timeout=30) as r:
        entries = json.load(r)
    shards = sorted([e for e in entries if ".tfrecord-" in e["path"]], key=lambda e: e["path"])
    counts = {t: 0 for t in tasks.values()}
    manifest = {"tasks": protocol["tasks"], "task": "three LIBERO-Spatial tasks", "episodes": [],
                "source": {"repo": REPO, "revision": REV, "shards": []},
                "validation_scope": "Held out from this update only; official base already saw LIBERO-Spatial."}
    seen = set()
    for entry in shards:
        if min(counts.values()) >= 12:
            break
        path = RAW / Path(entry["path"]).name
        if not path.exists():
            tmp = path.with_suffix(".partial")
            print("Downloading", path.name, flush=True)
            with tmp.open("wb") as output:
                for offset in range(0, entry["size"], 32*1024*1024):
                    end = min(offset+32*1024*1024, entry["size"])-1
                    url = f"https://huggingface.co/datasets/{REPO}/resolve/{REV}/{entry['path']}?part={offset}"
                    req = urllib.request.Request(url, headers={"Range": f"bytes={offset}-{end}"})
                    with urllib.request.urlopen(req, timeout=90) as response:
                        content = response.read()
                        assert response.status == 206 and len(content) == end-offset+1
                    output.write(content)
            tmp.replace(path)
        assert path.stat().st_size == entry["size"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["lfs"]["oid"]
        manifest["source"]["shards"].append(entry)
        for record_id, raw in enumerate(tf.compat.v1.io.tf_record_iterator(str(path))):
            features = tf.train.Example.FromString(raw).features.feature
            instruction = features["steps/language_instruction"].bytes_list.value[0].decode()
            if instruction not in tasks or counts[tasks[instruction]] >= 12:
                continue
            task = tasks[instruction]
            digest = hashlib.sha256(raw).hexdigest()
            assert digest not in seen
            seen.add(digest)
            actions = np.array(features["steps/action"].float_list.value, dtype=np.float32).reshape(-1, 7)
            images = []
            for encoded in features["steps/observation/image"].bytes_list.value:
                image = tf.io.decode_jpeg(encoded, channels=3)
                image = tf.image.resize(image, (224, 224), method="lanczos3", antialias=True)
                image = tf.cast(tf.clip_by_value(tf.round(image), 0, 255), tf.uint8)
                image = tf.image.convert_image_dtype(image, tf.float32)
                offset = (1-np.sqrt(.9))/2
                image = tf.image.crop_and_resize(image[None], [[offset,offset,1-offset,1-offset]], [0], (224,224))[0]
                images.append(tf.image.convert_image_dtype(tf.clip_by_value(image,0,1),tf.uint8,saturate=True).numpy())
            assert len(images) == len(actions) and np.isfinite(actions).all()
            idx = counts[task]
            split = "train" if idx < 10 else "validation"
            name = f"task{task}_{split}_{idx:02}.npz"
            np.savez_compressed(OUT/name, images=np.stack(images), actions=actions)
            if idx == 0:
                Image.fromarray(images[0]).save(OUT/f"task{task}_sample.png")
            manifest["episodes"].append({"file": name, "split": split, "task_id": task,
                "instruction": instruction, "steps": len(actions), "record_sha256": digest,
                "source_record": f"{path.name}:{record_id}"})
            counts[task] += 1
        print("Prepared episodes", counts, flush=True)
    assert min(counts.values()) == 12
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print("DATA READY", json.dumps(counts), flush=True)


if __name__ == "__main__":
    main()
