"""Preflight correctness and latency checks, without using test outcomes for selection."""
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from run_libero_4080 import configure_libero, load_model, preprocess
import numpy as np
import torch
from PIL import Image

configure_libero()
torch.set_num_threads(4)
from libero.libero import benchmark
from libero.libero.envs import OffScreenRenderEnv
suite = benchmark.get_benchmark_dict()["libero_spatial"]()
env = OffScreenRenderEnv(bddl_file_name=suite.get_task_bddl_file_path(0),camera_heights=256,camera_widths=256)
env.seed(0)
env.reset()
obs = env.set_init_state(suite.get_task_init_states(0)[0])
for _ in range(10):
    obs,_,_,_ = env.step([0,0,0,0,0,0,-1])
before = env.sim.get_state().flatten().copy()
low_before = env.sim.render(width=256,height=256,camera_name="agentview").copy()
hi = env.sim.render(width=720,height=720,camera_name="agentview")
low_after = env.sim.render(width=256,height=256,camera_name="agentview")
assert np.array_equal(before,env.sim.get_state().flatten()), "Extra rendering changed physical state"
assert np.array_equal(low_before,low_after), "Extra rendering changed 256px observation"
Image.fromarray(np.ascontiguousarray(hi[::-1,::-1])).save(ROOT/"language_experiment/preview_720.png")
image = preprocess(obs)
env.close()
model,processor = load_model()
prompt=f"In: What action should the robot take to {suite.get_task(0).language}?\nOut:"
inputs=processor(prompt,image).to("cuda:0",dtype=torch.bfloat16)
measurements=[]
reference=None
for threads in [1,4,8]:
    torch.set_num_threads(threads)
    times=[]
    for i in range(5):
        torch.cuda.synchronize(); start=time.perf_counter()
        with torch.inference_mode():
            action=model.predict_action(**inputs,unnorm_key="libero_spatial",do_sample=False)
        torch.cuda.synchronize()
        if i: times.append(time.perf_counter()-start)
        if reference is None: reference=action.copy()
        assert np.array_equal(reference,action), "CPU thread count altered generated actions"
    row={"threads":threads,"mean_seconds":float(np.mean(times))}
    measurements.append(row);print(row,flush=True)
result={"high_resolution_render_state_unchanged":True,"policy_pixels_unchanged":True,
        "cpu_thread_actions_equal":True,"latency_trials":measurements,
        "selected_threads":min(measurements,key=lambda r:r["mean_seconds"])["threads"]}
(ROOT/"language_experiment/preflight.json").write_text(json.dumps(result,indent=2))
print("PREFLIGHT PASSED",flush=True)
