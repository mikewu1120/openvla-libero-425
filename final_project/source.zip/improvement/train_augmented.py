"""Controlled language augmentation: same images, seed, budget and LoRA setup."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import train_qlora_4080 as training
import torch

HERE=Path(__file__).resolve().parent
PROTOCOL=json.loads((HERE/'protocol.json').read_text())
OriginalDemonstrations=training.Demonstrations
original_score=training.score
active_dataset=None

class AugmentedDemonstrations(OriginalDemonstrations):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        global active_dataset
        active_dataset=self
        self.augment=True
        self.counts={task['id']:[0,0,0] for task in PROTOCOL['tasks']}
        self.prefixes={}
        for task in PROTOCOL['tasks']:
            self.prefixes[task['id']]=[
                torch.tensor(self.processor.tokenizer(f'In: What action should the robot take to {text}?\nOut: ',add_special_tokens=True).input_ids)
                for text in task['training_instructions']]
        for (_,ids),task in zip(self.samples['train'],self.sample_tasks['train']):
            assert torch.equal(ids[:-8],self.prefixes[task][0]),'Prompt prefix mismatch'

    def batch(self,split,index):
        batch=super().batch(split,index)
        if split=='train' and self.augment:
            task=self.sample_tasks[split][index]
            variant=sum(self.counts[task])%3
            self.counts[task][variant]+=1
            ids=torch.cat((self.prefixes[task][variant],self.samples[split][index][1][-8:]))
            labels=ids.clone();labels[:-8]=-100
            batch.update(input_ids=ids[None].to('cuda'),labels=labels[None].to('cuda'),attention_mask=torch.ones_like(ids)[None].to('cuda'))
        return batch

def score_without_augmentation(model,dataset,split,count):
    previous=dataset.augment;dataset.augment=False
    try:
        return original_score(model,dataset,split,count)
    finally:
        dataset.augment=previous

if __name__=='__main__':
    training.Demonstrations=AugmentedDemonstrations
    training.score=score_without_augmentation
    sys.argv=[sys.argv[0],'--steps','300','--data',str(ROOT/'datasets/language_experiment'),'--output',str(ROOT/'training_runs/qlora_language_augmented')]
    training.main()
    path=ROOT/'training_runs/qlora_language_augmented/summary.json'
    report=json.loads(path.read_text())
    report['language_augmentation']={'instructions':{t['id']:t['training_instructions'] for t in PROTOCOL['tasks']},'sample_counts':active_dataset.counts,'test_instruction_strings_used_in_training':False,'exploratory_after_first_experiment':True}
    path.write_text(json.dumps(report,indent=2),encoding='utf-8')
