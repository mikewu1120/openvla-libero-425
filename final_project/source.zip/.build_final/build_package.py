"""Portable English results, slide viewer, notes, source and evidence."""
from pathlib import Path
import json, shutil, html, hashlib, zipfile
from reportlab.pdfgen import canvas

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'final_project'
for d in ['data','videos','slides','demos']: (OUT/d).mkdir(exist_ok=True)
read=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8'))
a=read('improvement/analysis.json');a.pop('narrative_zh',None)
rows=read('improvement/all_models_results.json');notes=read('.build_final/speaker_notes.json')
names={'base':'Base','qlora':'Original-only QLoRA','augmented':'Augmented QLoRA'}
for r in rows:
    name=f"{r['model']}_task{r['task_id']}_state{r['initial_state_index']:02d}_{r['variant']}.mp4"
    shutil.copy2(ROOT/r['directory']/'video.mp4',OUT/'videos'/name)
    r['video_path']='videos/'+name
for name,value in [('all_models_results',rows),('analysis',a)]:
    (OUT/f'data/{name}.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
for src,dst in [('language_experiment/protocol.json','original_protocol.json'),('improvement/protocol.json','augmentation_protocol.json'),('language_experiment/statistics.json','original_statistics.json'),('language_experiment/provenance.json','provenance.json'),('datasets/language_experiment/manifest.json','dataset_manifest.json'),('training_runs/qlora_language_3tasks/summary.json','original_training.json'),('training_runs/qlora_language_augmented/summary.json','augmented_training.json'),('improvement/selected_comparisons.json','augmentation_video_selection.json')]:
    shutil.copy2(ROOT/src,OUT/'data'/dst)
for i in range(1,14):shutil.copy2(ROOT/f'.build_final/renders/slide-{i:02d}.png',OUT/f'slides/slide-{i:02d}.png')
for src,dst in [('task1_comparison.mp4','paired_tradeoff.mp4'),('task1_preview.png','paired_tradeoff.png')]:
    shutil.copy2(ROOT/'language_experiment/comparisons'/src,OUT/'demos'/dst)
pdf=canvas.Canvas(str(OUT/'OpenVLA_Slides.pdf'),pagesize=(960,540))
pdf.setTitle('OpenVLA Language Robustness - Slides')
for i in range(1,14):
    pdf.drawImage(str(OUT/f'slides/slide-{i:02d}.png'),0,0,width=960,height=540);pdf.showPage()
pdf.save()
css='''body{font:17px/1.6 Arial,sans-serif;margin:0;color:#15263b;background:#f4f6f8}main{max-width:1100px;margin:auto;padding:36px 28px}h1{font-size:34px;line-height:1.2}h2{margin-top:32px}a{color:#2764a5}nav{display:flex;flex-wrap:wrap;gap:18px}section{background:white;padding:24px;margin:22px 0;border:1px solid #d7dfe6}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #d7dfe6}th{background:#edf2f6}video{width:100%;max-height:660px;background:#111}select,button{font:inherit;padding:8px;margin:6px}pre{white-space:pre-wrap;background:#edf2f6;padding:15px;font-size:14px}.muted{color:#546576}.good{color:#187453}.bad{color:#b32929}@media print{body{background:white}main{padding:0}section{break-inside:avoid}nav{display:none}}'''
def save(name,title,body):
    (OUT/name).write_text(f'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{css}</style><main>{body}</main></html>',encoding='utf-8')
nav='<nav><a href="index.html">Results</a><a href="presentation.html">Offline presentation</a><a href="OpenVLA_Final.pptx">PowerPoint</a><a href="OpenVLA_Report.pdf">Report</a><a href="speaker_notes.html">Speaker notes and Q&amp;A</a><a href="reproduce.html">Reproduction guide</a></nav>'
summary='<tr><th>Model</th><th>Original</th><th>P1</th><th>P2</th><th>Overall</th><th>Gap</th></tr>'
for i,m in enumerate(a['models']):
    total=sum(sum(t) for t in a['counts'][i])
    summary+=f'<tr><td>{names[m]}</td>'+''.join(f'<td>{v*100:.1f}%</td>' for v in a['rates'][i])+f'<td>{total}/90</td><td>{a["gaps"][i]*100:.1f} pp</td></tr>'
body=f'''<h1>Language Robustness in OpenVLA</h1>{nav}<p>270 completed simulation rollouts · Three models · RTX 4080 Laptop, 12 GB</p><section><h2>Measured results</h2><table>{summary}</table><p>Language augmentation improves aggregate success on these reused cases, but the primary robustness-gap change remains inconclusive: <b>-3.3 pp, 95% paired interval [-13.3, +6.7]</b> relative to original-only training.</p><p class="muted">Exploratory follow-up, one training seed, three related tasks and two evaluation paraphrases. The official starting checkpoint was already trained on LIBERO-Spatial.</p></section>'''
for title,file,desc in [('Original-only trade-off','paired_tradeoff','Task 1, state 9, P2. Original changes from failure to success while the paraphrase changes from success to failure.'),('Augmentation gain','augmentation_task2','Task 2, state 0, P2. Both original and paraphrase change from failure to success.'),('Augmentation regression','augmentation_task0','Task 0, state 1, P2. The original still succeeds, but the paraphrase changes from success to failure.')]:
    body+=f'<section><h2>{title}</h2><p>{desc}</p><video controls preload="metadata" poster="demos/{file}.png" src="demos/{file}.mp4"></video><p class="muted">Selected after inspecting outcomes for illustration, not frequency estimation. 0.5x simulation time; finished panels hold their final frame.</p></section>'
body+='''<section><h2>Explore all 270 rollouts</h2><p>Select any model, task, wording and initial state. Failures are retained.</p><label>Model <select id="model"><option value="base">Base</option><option value="qlora">Original-only QLoRA</option><option value="augmented" selected>Augmented QLoRA</option></select></label><label>Task <select id="task"><option value="0">Between</option><option value="1">Next to</option><option value="2" selected>Table center</option></select></label><label>Wording <select id="variant"><option value="original">Original</option><option value="paraphrase_1">Paraphrase 1</option><option value="paraphrase_2" selected>Paraphrase 2</option></select></label><label>Initial state <select id="state">'''+''.join(f'<option>{i}</option>' for i in range(10))+'''</select></label><p id="instruction"></p><p id="outcome"></p><video id="rollout" controls preload="metadata"></video><p class="muted">720 x 720 native rendering, 20 fps simulation time. This is not real-time model inference.</p></section><section><h2>What to improve next</h2><ol><li>Freeze the intervention and evaluate new paraphrases and unused initial states.</li><li>Repeat training across seeds and report uncertainty across seeds and paired scenes.</li><li>Add same-scene, different-target and no-instruction controls with appropriate success predicates.</li></ol><p>These are proposed follow-ups, not completed experiments.</p><p><a href="data/all_models_results.json">All outcomes</a> · <a href="data/analysis.json">Paired analysis</a> · <a href="source.zip">Source and trained adapters</a></p></section>'''
body+='<script>const rows='+json.dumps(rows)+';const ids=["model","task","variant","state"];function update(){const [m,t,v,s]=ids.map(id=>document.getElementById(id).value);const r=rows.find(r=>r.model===m&&r.task_id===+t&&r.variant===v&&r.initial_state_index===+s);document.getElementById("instruction").textContent=r.instruction;const o=document.getElementById("outcome");o.textContent=(r.success?"SUCCESS":"FAILURE")+" · "+r.steps+" actions · "+r.wall_seconds.toFixed(1)+" seconds measured rollout wall time";o.className=r.success?"good":"bad";document.getElementById("rollout").src=r.video_path;}ids.forEach(id=>document.getElementById(id).addEventListener("change",update));update();</script>'
save('index.html','OpenVLA experiment results',body)
presentation='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OpenVLA offline presentation</title><style>body{margin:0;background:#15263b;color:white;font:16px Arial}#stage{position:relative;width:min(100vw,calc((100vh - 60px)*16/9));aspect-ratio:16/9;margin:auto;background:white}#slide{width:100%;height:100%}video{position:absolute;left:12.109375%;top:17.361111%;width:75.78125%;height:75.833333%;background:#111}nav{height:54px;display:flex;gap:14px;align-items:center;justify-content:center}button,a{font:inherit;color:inherit;background:transparent;border:1px solid #8494a8;padding:7px 12px;text-decoration:none}#counter{min-width:130px;text-align:center}</style><div id="stage"><img id="slide" alt="Presentation slide"><video id="demo" controls preload="metadata" src="demos/paired_tradeoff.mp4" hidden></video></div><nav><button id="prev">Previous</button><span id="counter"></span><button id="next">Next</button><button id="full">Fullscreen</button><a href="index.html">Results</a></nav><script>let i=1;const image=document.getElementById('slide'),video=document.getElementById('demo');function show(n){i=Math.max(1,Math.min(13,n));video.pause();video.currentTime=0;image.src='slides/slide-'+String(i).padStart(2,'0')+'.png';video.hidden=i!==7;document.getElementById('counter').textContent=i+' / 13'+(i>10?' · Appendix':'');history.replaceState(null,'','#'+i);}document.getElementById('prev').onclick=()=>show(i-1);document.getElementById('next').onclick=()=>show(i+1);document.getElementById('full').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();document.addEventListener('keydown',e=>{if(['ArrowRight','PageDown'].includes(e.key)){e.preventDefault();show(i+1);}if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();show(i-1);}if(e.code==='Space'){e.preventDefault();if(i===7){video.paused?video.play():video.pause();}else show(i+1);}});show(Number(location.hash.slice(1))||1);</script></html>'''
(OUT/'presentation.html').write_text(presentation,encoding='utf-8')
faq=[
('What did you train?','Low-rank query/value adapters on a frozen NF4 OpenVLA LIBERO-Spatial checkpoint. Each run has 300 updates and 4.19 million trainable parameters. This is not training a 7B model from scratch.'),
('What is the main result?','Original-only training increases total success but does not narrow the primary robustness gap. Augmentation reaches 69/90 successes, yet its gap-change interval [-13.3, 6.7] includes zero.'),
('Does the interval prove no effect?','No. It is compatible with both a reduction and an increase of the gap on these fixed tasks. It does not establish equivalence.'),
('Why are 270 rollouts not independent?','Each task-state case is reused across models and wordings. Bootstrap resampling keeps those conditions together and resamples states within each fixed task.'),
('Is the gain caused by better language understanding?','The experiment does not isolate that mechanism. Different-target and no-instruction controls would help test language dependence.'),
('Was the test set used during training?','Added training strings differ from evaluation paraphrases. However, augmentation was designed after inspecting original results and reuses evaluation cases, so it is exploratory. The base also already saw LIBERO-Spatial.'),
('Why show selected videos?','They illustrate paired gains, regressions and disagreements. Selection is disclosed; the complete gallery and numerical results give frequencies.'),
('How does this fit 12 GB?','Frozen four-bit weights, limited rank-eight adapters, batch size one and gradient checkpointing. Peak allocated memory is about 5.51 GiB, which is not total device usage.'),
('What should be done next?','Freeze the recipe, use new paraphrases and initial states, repeat training seeds and add language-necessity controls. Do not repeatedly tune on this test set.')]
body=f'<h1>Speaker notes and Q&amp;A</h1>{nav}<p>Ten main slides and three appendix slides. Planned main segment: 7 minutes 40 seconds including the 24-second demonstration. The approximately 801-word script leaves time for pointing and pauses. Rehearse aloud before class.</p><p>Use Presenter View in PowerPoint. On slide 7, click the video. In the offline viewer, arrow keys navigate and Space plays or pauses the video. The slides PDF has static frames only.</p>'
for n in notes:
    timing=f'Target: {n["seconds"]} seconds' if n['seconds'] else 'Appendix: use during questions'
    body+=f'<section><h2>{n["slide"]}. {html.escape(n["title"])}</h2><p class="muted">{timing}</p><p>{html.escape(n["english"])}</p></section>'
body+='<h2>Questions to prepare for</h2>'+''.join(f'<section><h3>{q}</h3><p>{ans}</p></section>' for q,ans in faq)
save('speaker_notes.html','OpenVLA speaker notes and Q&A',body)
guide=r'''<h1>Reproduction and presentation guide</h1>'''+nav+r'''
<section><h2>Present without running the model</h2><ol>
<li>Keep this folder intact. Open the PowerPoint file or the offline browser presentation.</li>
<li>Present slides 1-10. Slides 11-13 are for questions. Planned main segment: 7:40 including video.</li>
<li>Click the video on slide 7. Independent backup: <a href="demos/paired_tradeoff.mp4">paired_tradeoff.mp4</a>.</li>
<li>Use the English script and Q&amp;A. Add your preferred presenter name to the editable cover before submission.</li>
<li>The report has four body pages plus one reference page. Nothing has been submitted or published online.</li>
</ol><p>The browser presentation, report and videos work offline. The browser preserves slide appearance; PowerPoint contains editable content.</p></section>
<section><h2>Recorded workspace</h2><p>The working project is at <code>C:\Users\15147\Desktop\425</code>. The source archive preserves relative paths for scripts, protocols, adapters and compact metadata. Large base weights, demonstrations and raw traces remain in the working project; the source archive is not a standalone environment installer.</p>
<p>Adapters: <code>training_runs/qlora_language_3tasks/adapter</code> and <code>training_runs/qlora_language_augmented/adapter</code>.</p>
<p>Raw evidence: <code>language_experiment/rollouts</code> and <code>improvement/rollouts</code>. Each completed cell contains result.json, actions.json, states.npz and video.mp4. The historical extension evaluator labels its model "qlora"; combined analysis normalizes it to "augmented" using its directory and adapter hash.</p></section>
<section><h2>Recompute analysis in the existing workspace</h2><pre>.\.venv\Scripts\python.exe language_experiment\summarize.py
.\.venv\Scripts\python.exe improvement\analyze_extension.py
.\.venv\Scripts\python.exe improvement\make_final_figures.py</pre>
<p>The extension analysis checks all 270 paired state/action traces and the 90 new videos. Original video validation is in language_experiment/validation.json. These CPU analyses do not retrain the model.</p></section>
<section><h2>Repeat in a fresh workspace copy</h2><p>Preserve the completed experiment. Copy the code and inputs into a separate directory with new output folders. Training refuses to overwrite an existing run. Use Python 3.10, requirements-windows.lock.txt, and the official code/model/data revisions recorded in data/provenance.json.</p>
<pre>.\.venv\Scripts\python.exe apply_windows_fixes.py
.\.venv\Scripts\python.exe language_experiment\prepare_data.py
.\.venv\Scripts\python.exe train_qlora_4080.py --steps 300 --data datasets/language_experiment --output training_runs/qlora_language_3tasks
.\.venv\Scripts\python.exe language_experiment\finish_run.py
.\.venv\Scripts\python.exe improvement\train_augmented.py
.\.venv\Scripts\python.exe improvement\run_extension.py</pre>
<p>Data preparation expects the verified RLDS shards under datasets/training_subset/raw. Evaluation uses five cells per subprocess to avoid the observed Windows MuJoCo asset-loading issue, resumes completed cells, and checks protocol/checkpoint hashes. A changed protocol requires a separate output location.</p>
<p>Training: seed 7, 300 updates, batch 1, accumulation 4, NF4, rank 8, alpha 16, query/value targets, learning rate 1e-4. Different hardware or dependency versions may change numerical outcomes.</p></section>
<section><h2>Rebuild the presentation package</h2><p>The source archive includes .build_final/build_deck.mjs, embed_video.py, build_report.py and build_package.py. Slides use @oai/artifact-tool, the report uses ReportLab, and scientific figures use Matplotlib. PresentationML media embedding retains native charts and tables. Run the immutable presentation finalizer from the installed Presentations skill before publishing a rebuilt PPTX.</p>
<p>Build order: analysis, scientific figures and comparison videos, build_deck.mjs, embed_video.py, finalize_deck.mjs, build_report.py, build_package.py. Bundled-runtime paths in build scripts are machine-specific.</p></section>
<section><h2>Interpretation</h2><p>Gap = original success minus mean P1/P2 success. Both primary gap-change intervals include zero. Augmentation was designed after seeing the first results and reuses cases. New paraphrases, new initial states and repeated training seeds are needed for a stronger generalization claim.</p></section>'''
save('reproduce.html','OpenVLA reproduction guide',guide)
sources=[]
for pattern in ['*.py','requirements-windows.lock.txt','language_experiment/*.py','language_experiment/*.json','improvement/*.py','improvement/*.json','.build_final/*.mjs','.build_final/*.py','training_runs/qlora_language_3tasks/adapter/*','training_runs/qlora_language_augmented/adapter/*']:
    sources.extend(p for p in ROOT.glob(pattern) if p.is_file())
with zipfile.ZipFile(OUT/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(sources)):z.write(p,p.relative_to(ROOT))
manifest={p.relative_to(OUT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file() and p.name!='sha256.json'}
(OUT/'sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(f'Portable bundle: {len(rows)} videos, {len(notes)} slides, English notes and guide')
