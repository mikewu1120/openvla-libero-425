"""Analyze all three models with state-paired resampling and audit new videos."""
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
import imageio.v2 as imageio

ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
base=json.loads((ROOT/'language_experiment/all_results.json').read_text())
new=[]
protocol_hash=hashlib.sha256((HERE/'protocol.json').read_bytes()).hexdigest()
adapter_hash=hashlib.sha256((ROOT/'training_runs/qlora_language_augmented/adapter/adapter_model.safetensors').read_bytes()).hexdigest()
for path in sorted((HERE/'rollouts').glob('*/result.json')):
    r=json.loads(path.read_text());assert r['protocol_sha256']==protocol_hash and r['adapter_sha256']==adapter_hash
    r['model']='augmented';r['directory']=path.parent.relative_to(ROOT).as_posix();new.append(r)
assert len(new)==90,'All ninety extension cases are required'
for r in base:r['directory']='language_experiment/'+r['directory']
rows=base+new
models=['base','qlora','augmented'];variants=['original','paraphrase_1','paraphrase_2']
values=np.zeros((3,3,10,3));states={};images={};keys=set()
for r in rows:
    k=(r['model'],r['task_id'],r['initial_state_index'],r['variant']);assert k not in keys;keys.add(k)
    t,s=k[1:3];values[models.index(k[0]),t,s,variants.index(k[3])]=r['success']
    with np.load(ROOT/r['directory']/'states.npz') as archive:
        initial=archive['states'][0].copy();assert len(archive['states'])==r['steps']+1 and np.isfinite(archive['states']).all()
    if (t,s) in states:assert np.array_equal(initial,states[t,s]) and images[t,s]==r['initial_image_sha256']
    states[t,s]=initial;images[t,s]=r['initial_image_sha256']
    actions=json.loads((ROOT/r['directory']/'actions.json').read_text());assert len(actions)==r['steps'] and np.isfinite([a['raw'] for a in actions]).all()

def video_check(r):
    with imageio.get_reader(str(ROOT/r['directory']/'video.mp4')) as reader:
        meta=reader.get_meta_data();assert meta['size']==(720,720) and meta['fps']==20
        assert reader.count_frames()==r['steps']+1
        reader.get_data(r['steps'])
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(video_check,new))
rates=values.mean(axis=(1,2));gaps=rates[:,0]-rates[:,1:].mean(axis=1)
rng=np.random.default_rng(7);samples=[]
for _ in range(5000):
    sampled=np.stack([values[:,t,rng.integers(10,size=10),:] for t in range(3)],axis=1)
    samples.append(sampled.mean(axis=(1,2)))
samples=np.array(samples);sample_gaps=samples[:,:,0]-samples[:,:,1:].mean(axis=2)
changes={}
for comparator in [0,1]:
    changes[models[comparator]]={
      'success_rate_difference':(rates[2]-rates[comparator]).tolist(),
      'success_difference_ci95':np.quantile(samples[:,2]-samples[:,comparator],[.025,.975],axis=0).tolist(),
      'gap_difference':float(gaps[2]-gaps[comparator]),
      'gap_difference_ci95':np.quantile(sample_gaps[:,2]-sample_gaps[:,comparator],[.025,.975]).tolist(),
      'improved':int(((values[2]==1)&(values[comparator]==0)).sum()),
      'regressed':int(((values[2]==0)&(values[comparator]==1)).sum())}
counts=values.sum(axis=2).astype(int)
a=rates[2]*100;delta=(gaps[2]-gaps[1])*100;ci=np.array(changes['qlora']['gap_difference_ci95'])*100
direction='smaller' if delta<0 else ('larger' if delta>0 else 'unchanged')
evidence='The paired interval includes zero, so this follow-up does not establish a gap reduction.' if ci[0]<=0<=ci[1] else 'The paired interval excludes zero for these reused cases, but independent validation is still required.'
result={'models':models,'rates':rates.tolist(),'counts':counts.tolist(),'gaps':gaps.tolist(),'changes':changes,'rollouts':270,'new_videos_validated':90,'paired_states_validated':30,'protocol_sha256':protocol_hash,'adapter_sha256':adapter_hash,'exploratory':True,
'narrative_en':f'The augmented model succeeds in {a[0]:.1f} percent of original instructions, {a[1]:.1f} percent of paraphrase one, and {a[2]:.1f} percent of paraphrase two. Its original-minus-paraphrase gap is {gaps[2]*100:.1f} points. Compared with original-only training, the gap is {direction}, with a change of {delta:.1f} points and a paired interval from {ci[0]:.1f} to {ci[1]:.1f}. {evidence} The intervention was designed after inspecting the initial results, and the same evaluation cases are reused. We must therefore interpret it as an exploratory result, not broad language generalization.',
'narrative_zh':f'新增模型原句、改写1、改写2成功率分别为 {a[0]:.1f}%、{a[1]:.1f}%、{a[2]:.1f}%。相对原句微调，主差距变化 {delta:.1f} 个百分点，95%配对区间 [{ci[0]:.1f}, {ci[1]:.1f}]。这是观察首轮结果后提出、复用测试案例的探索性分析，不能当作独立确认。',
'slide_takeaway':f'Gap vs original-only training: {delta:+.1f} pp\n95% paired interval: {ci[0]:+.1f} to {ci[1]:+.1f} pp'}
(HERE/'analysis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
(HERE/'all_models_results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2,ensure_ascii=True),flush=True)
