process.env.RUNTIME_NODE_MODULES='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1117-835-0_26.1117.835.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const ROOT='C:/Users/15147/Desktop/425';
const SKILL='C:/Users/15147/.codex/plugins/cache/openai-primary-runtime/presentations/26.1117.11355/skills/presentations';
const PY='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1117-835-0_26.1117.835.0_x64__3k8sg7r9htsxt/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const source=process.argv[2]??'.build_final/candidate.pptx';
const target=process.argv[3]??'.build_final/validated_draft_v1.pptx';
const result=await finalizePresentation({workspaceDir:ROOT,candidatePath:path.join(ROOT,source),finalPath:path.join(ROOT,target),pythonExecutable:PY,
integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','3','--require-native-table-slide','6','--require-native-table-slide','11'],requiredNativeTableOwnerSlides:[3,6,11],requiredNativeChartOwnerSlides:[5,9],fontPolicy:{basis:'design',families:['Arial']},materializeLiteralChartWorkbooks:true,nativeChartTargetApplication:'powerpoint',verifyArtifactToolImport:true,receiptPath:path.join(ROOT,'.build_final',path.basename(target)+'.validation.json')});
console.log(JSON.stringify(result));
