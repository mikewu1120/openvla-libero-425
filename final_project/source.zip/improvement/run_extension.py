"""Finish the fixed exploratory extension and retain all paired evidence."""
import json
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
summary=ROOT/'training_runs/qlora_language_augmented/summary.json'
while not summary.exists():
    time.sleep(30)
    print('Waiting for augmented training to finish',flush=True)
training=json.loads(summary.read_text())
assert training['status']=='complete' and training['completed_updates']==300
count=len(list((HERE/'rollouts').glob('*/result.json')))
while count<90:
    with (HERE/'evaluation_console.log').open('a',encoding='utf-8') as log:
        process=subprocess.Popen([sys.executable,'-u',str(HERE/'evaluate.py'),'--model','qlora','--max-jobs','5'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
        for line in process.stdout:
            log.write(line);log.flush()
            if line.startswith(('START ','DONE ','PROGRESS ','Traceback','AssertionError','RuntimeError')):print(line.rstrip(),flush=True)
        assert process.wait()==0,'See evaluation_console.log'
    new_count=len(list((HERE/'rollouts').glob('*/result.json')))
    assert new_count>count
    count=new_count
print('AUGMENTED EVALUATION COMPLETE: 90/90',flush=True)
subprocess.run([sys.executable,'-u',str(HERE/'analyze_extension.py')],cwd=ROOT,check=True)
