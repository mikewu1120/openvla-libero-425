"""Run all fixed, paired language-robustness cells; retain videos and trajectories."""
import argparse
import gc
import hashlib
import importlib.metadata
import json
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from run_libero_4080 import configure_libero, load_model, preprocess
import imageio.v2 as imageio
import numpy as np
import torch
from PIL import Image

EXPERIMENT = ROOT / "language_experiment"
ADAPTER = ROOT / "training_runs/qlora_language_3tasks/adapter"


def write_json(path, data):
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["base","qlora","all"], default="all")
    parser.add_argument("--max-jobs", type=int, default=0, help="0 means all remaining cells")
    args = parser.parse_args()
    protocol_bytes=(EXPERIMENT/"protocol.json").read_bytes()
    protocol=json.loads(protocol_bytes)
    protocol_hash=hashlib.sha256(protocol_bytes).hexdigest()
    evaluator_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    policy_hash=hashlib.sha256((ROOT/"run_libero_4080.py").read_bytes()).hexdigest()
    preflight=json.loads((EXPERIMENT/"preflight.json").read_text())
    torch.set_num_threads(preflight["selected_threads"])
    random.seed(7);np.random.seed(7);torch.manual_seed(7);torch.cuda.manual_seed_all(7)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False
    configure_libero()
    from libero.libero import benchmark
    from libero.libero.envs import OffScreenRenderEnv
    suite=benchmark.get_benchmark_dict()[protocol["suite"]]()
    output=EXPERIMENT/"rollouts"
    output.mkdir(exist_ok=True)
    models=protocol["models"] if args.model=="all" else [args.model]
    references={}
    for path in output.glob("*/result.json"):
        previous=json.loads(path.read_text())
        assert previous["protocol_sha256"]==protocol_hash
        assert previous["evaluator_sha256"]==evaluator_hash and previous["policy_code_sha256"]==policy_hash
        references[(previous["task_id"],previous["initial_state_index"])]=previous["initial_image_sha256"]
    completed_now=0
    for model_name in models:
        adapter_hash=hashlib.sha256((ADAPTER/"adapter_model.safetensors").read_bytes()).hexdigest() if model_name=="qlora" else None
        print(f"Loading {model_name}",flush=True)
        model,processor=load_model()
        if model_name=="qlora":
            from peft import PeftModel
            model=PeftModel.from_pretrained(model,ADAPTER,is_trainable=False)
            model.eval()
        for task_config in protocol["tasks"]:
            task_id=task_config["id"]
            task=suite.get_task(task_id)
            assert task.language==task_config["original"]
            init_states=suite.get_task_init_states(task_id)
            env=OffScreenRenderEnv(bddl_file_name=suite.get_task_bddl_file_path(task_id),
                                  camera_heights=256,camera_widths=256)
            try:
                for state_id in protocol["initial_state_indices"]:
                    for variant in protocol["variants"]:
                        name=f"{model_name}_task{task_id}_state{state_id:02}_{variant}"
                        folder=output/name
                        folder.mkdir(exist_ok=True)
                        result_path=folder/"result.json"
                        if result_path.exists():
                            previous=json.loads(result_path.read_text())
                            assert previous["protocol_sha256"]==protocol_hash and previous["adapter_sha256"]==adapter_hash
                            continue
                        instruction=task_config[variant]
                        print(f"START {name}",flush=True)
                        env.seed(0)
                        env.reset()
                        obs=env.set_init_state(init_states[state_id])
                        for _ in range(protocol["settle_steps"]):
                            obs,_,_,_=env.step([0,0,0,0,0,0,-1])
                        initial_hash=hashlib.sha256(obs["agentview_image"].tobytes()).hexdigest()
                        key=(task_id,state_id)
                        if key in references:
                            assert references[key]==initial_hash, f"Unpaired initial scene: {name}"
                        references[key]=initial_hash
                        Image.fromarray(np.ascontiguousarray(obs["agentview_image"][::-1,::-1])).save(folder/"initial_policy_view.png")
                        actions=[];states=[];latencies=[];success=False
                        torch.cuda.reset_peak_memory_stats()
                        wall_start=time.perf_counter()
                        prompt=f"In: What action should the robot take to {instruction.lower()}?\nOut:"
                        try:
                            with imageio.get_writer(str(folder/"video.mp4"),fps=protocol["video_fps"],
                                                    codec="libx264",quality=7,macro_block_size=16) as video:
                                for step in range(protocol["max_action_steps"]):
                                    states.append(env.sim.get_state().flatten().copy())
                                    frame=env.sim.render(width=720,height=720,camera_name="agentview")
                                    video.append_data(np.ascontiguousarray(frame[::-1,::-1]))
                                    image=preprocess(obs)
                                    inputs=processor(prompt,image).to("cuda:0",dtype=torch.bfloat16)
                                    torch.cuda.synchronize();start=time.perf_counter()
                                    with torch.inference_mode():
                                        raw=model.predict_action(**inputs,unnorm_key="libero_spatial",do_sample=False)
                                    torch.cuda.synchronize();latencies.append(time.perf_counter()-start)
                                    assert raw.shape==(7,) and np.isfinite(raw).all()
                                    action=raw.copy();action[-1]=-np.sign(2*action[-1]-1)
                                    actions.append({"step":step,"raw":raw.tolist(),"executed":action.tolist(),"inference_seconds":latencies[-1]})
                                    obs,_,done,_=env.step(action.tolist())
                                    if step%50==0:
                                        write_json(EXPERIMENT/"progress.json",{"current":name,"step":step,
                                            "completed":len(list(output.glob('*/result.json'))),"expected":180})
                                        print(f"PROGRESS {name} step={step}",flush=True)
                                    if done:
                                        success=True
                                        break
                                states.append(env.sim.get_state().flatten().copy())
                                frame=np.ascontiguousarray(env.sim.render(width=720,height=720,camera_name="agentview")[::-1,::-1])
                                video.append_data(frame)
                                Image.fromarray(frame).save(folder/"final.png")
                            np.savez_compressed(folder/"states.npz",states=np.stack(states),initial_state=init_states[state_id])
                            write_json(folder/"actions.json",actions)
                            result={"model":model_name,"task_id":task_id,"task_label":task_config["label"],
                                "initial_state_index":state_id,"variant":variant,"instruction":instruction,
                                "status":"complete","success":success,"steps":len(actions),
                                "mean_inference_seconds":float(np.mean(latencies)),"wall_seconds":time.perf_counter()-wall_start,
                                "peak_allocated_gib":torch.cuda.max_memory_allocated()/1024**3,
                                "protocol_sha256":protocol_hash,"adapter_sha256":adapter_hash,
                                "evaluator_sha256":evaluator_hash,"policy_code_sha256":policy_hash,
                                "base_revision":"962318cec55ac10993ff0f5f43eda9a270b4c873",
                                "initial_image_sha256":initial_hash,"video":"video.mp4","video_resolution":[720,720],
                                "video_fps":20,"timebase":"simulation time, not real inference time",
                                "cpu_threads":preflight["selected_threads"],"model_seed":7,"environment_seed":0}
                            result["versions"]={name:importlib.metadata.version(name) for name in ["torch","transformers","bitsandbytes","peft","mujoco","robosuite"]}
                            write_json(result_path,result)
                            completed_now+=1
                            completed=len(list(output.glob("*/result.json")))
                            write_json(EXPERIMENT/"progress.json",{"completed":completed,"expected":180,"last":name,"success":success})
                            print(f"DONE {completed}/180 {name} success={success} steps={len(actions)} wall={result['wall_seconds']:.1f}s",flush=True)
                        except Exception as error:
                            write_json(folder/"error.json",{"error":repr(error),"step":len(actions),"scored_as_failure":False})
                            raise
                        if args.max_jobs and completed_now>=args.max_jobs:
                            return
            finally:
                env.close()
        del model,processor
        gc.collect();torch.cuda.empty_cache()
    print("EVALUATION COMPLETE",flush=True)


if __name__=="__main__":
    main()
