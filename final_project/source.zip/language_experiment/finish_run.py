"""Run the fixed evaluation, paired analysis and comparison-video export in order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/"language_experiment"
training=json.loads((ROOT/"training_runs/qlora_language_3tasks/summary.json").read_text())
assert training["status"]=="complete" and training["completed_updates"]==300
assert training["sampled_frames_per_task"]=={"0":400,"1":400,"2":400}
def run_stage(script, arguments=()):
    print("START STAGE",script,*arguments,flush=True)
    with (HERE/(Path(script).stem+"_console.log")).open("a",encoding="utf-8") as log:
        process=subprocess.Popen([sys.executable,"-u",str(HERE/script),*arguments],cwd=ROOT,
                                  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding="utf-8",errors="replace")
        for line in process.stdout:
            log.write(line);log.flush()
            if line.startswith(("START ","DONE ","PROGRESS ","Created ","EVALUATION ","Traceback","AssertionError","RuntimeError")):
                print(line.rstrip(),flush=True)
        if process.wait()!=0:
            raise RuntimeError(f"Stage {script} failed; see {log.name}")

# Pinned MuJoCo on Windows exhausts file resources after repeated model loads.
# Keep identical simulation/inference code; release native resources per five cells.
for model in ['base','qlora']:
    completed=len(list((HERE/'rollouts').glob(model+'_*/result.json')))
    while completed<90:
        run_stage('evaluate.py',['--model',model,'--max-jobs','5'])
        new_count=len(list((HERE/'rollouts').glob(model+'_*/result.json')))
        assert new_count>completed, 'Evaluation chunk made no progress'
        completed=new_count
for script in ['summarize.py','make_comparisons.py','validate_outputs.py']:
    run_stage(script)
print("ALL EXPERIMENT STAGES COMPLETE",flush=True)
