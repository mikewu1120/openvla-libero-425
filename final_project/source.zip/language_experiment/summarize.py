"""Paired descriptive analysis and a local video index for the fixed 180-cell run."""
import html
import json
import os
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"]=str(HERE.parent/".cache/matplotlib")


def paired_statistics(values, repetitions=5000):
    """values axes: model, task, initial state, instruction variant."""
    rng=np.random.default_rng(7)
    estimates=values.mean(axis=(1,2))
    samples=[]
    for _ in range(repetitions):
        selected=np.stack([values[:,t,rng.integers(values.shape[2],size=values.shape[2]),:]
                           for t in range(values.shape[1])],axis=1)
        samples.append(selected.mean(axis=(1,2)))
    samples=np.stack(samples)
    gaps=estimates[:,0]-estimates[:,1:].mean(axis=1)
    sampled_gaps=samples[:,:,0]-samples[:,:,1:].mean(axis=2)
    return {"success_rates":estimates.tolist(),"success_ci95":np.quantile(samples,[.025,.975],axis=0).tolist(),
            "robustness_gap":gaps.tolist(),"gap_ci95":np.quantile(sampled_gaps,[.025,.975],axis=0).tolist(),
            "gap_change_qlora_minus_base":float(gaps[1]-gaps[0]),
            "gap_change_ci95":np.quantile(sampled_gaps[:,1]-sampled_gaps[:,0],[.025,.975]).tolist(),
            "ci_method":"5000 paired bootstrap resamples of initial-state indices within each fixed task; seed 7. Conditional on these tasks and one training seed."}


def main():
    protocol=json.loads((HERE/"protocol.json").read_text())
    models=protocol["models"];variants=protocol["variants"]
    results=[]
    for path in sorted((HERE/"rollouts").glob("*/result.json")):
        row=json.loads(path.read_text())
        row["directory"]=path.parent.relative_to(HERE).as_posix()
        results.append(row)
    assert len(results)==180, f"Expected 180 results, got {len(results)}"
    values=np.zeros((2,3,10,3),dtype=float)
    keyed={}
    hashes={}
    for row in results:
        key=(row["model"],row["task_id"],row["initial_state_index"],row["variant"])
        assert key not in keyed and row["status"]=="complete"
        keyed[key]=row
        paired_key=key[1:3]
        if paired_key in hashes: assert hashes[paired_key]==row["initial_image_sha256"]
        hashes[paired_key]=row["initial_image_sha256"]
        values[models.index(key[0]),key[1],key[2],variants.index(key[3])]=row["success"]
        directory=HERE/row["directory"]
        actions=json.loads((directory/"actions.json").read_text())
        assert len(actions)==row["steps"] and 0<row["steps"]<=220
        assert np.isfinite(np.array([a["raw"] for a in actions])).all()
        with np.load(directory/"states.npz") as saved:
            assert len(saved["states"])==row["steps"]+1
        assert (directory/"video.mp4").stat().st_size>0
    statistics=paired_statistics(values)
    pairs=[]
    for task in range(3):
        for state in range(10):
            for variant in variants[1:]:
                cells=[keyed[(model,task,state,v)] for model in models for v in ["original",variant]]
                bo,bp,qo,qp=[int(r["success"]) for r in cells]
                pairs.append({"task_id":task,"state":state,"variant":variant,
                              "base_original":bo,"base_paraphrase":bp,"qlora_original":qo,"qlora_paraphrase":qp,
                              "discordance":int(bo!=bp)+int(qo!=qp)+int(bp!=qp),
                              "directories":[r["directory"] for r in cells]})
    selected=[sorted([p for p in pairs if p["task_id"]==task],key=lambda p:(-p["discordance"],p["state"],p["variant"]))[0]
              for task in range(3)]
    for p in selected:
        p["selection_rule"]="Maximum observed discordance within task, then lowest initial-state index and variant name; illustrative, not representative frequency."
    statistics["paired_counts"]={}
    for model in models:
        prefix="base" if model=="base" else "qlora"
        statistics["paired_counts"][model]={
            "original_success_paraphrase_failure":sum(p[prefix+"_original"]==1 and p[prefix+"_paraphrase"]==0 for p in pairs),
            "original_failure_paraphrase_success":sum(p[prefix+"_original"]==0 and p[prefix+"_paraphrase"]==1 for p in pairs),
            "paired_comparisons":60}
    statistics["total_rollouts"]=180
    statistics["per_task_success_counts"]=values.sum(axis=2).astype(int).tolist()
    statistics["selected_video_pairs"]=selected
    statistics["hypotheses"]=protocol["hypotheses"]
    statistics["limitations"]=protocol["limits"]
    (HERE/"statistics.json").write_text(json.dumps(statistics,indent=2),encoding="utf-8")
    (HERE/"all_results.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
    (HERE/"paired_results.json").write_text(json.dumps(pairs,indent=2),encoding="utf-8")
    (HERE/"selected_comparisons.json").write_text(json.dumps(selected,indent=2),encoding="utf-8")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    figures=HERE/"figures";figures.mkdir(exist_ok=True)
    rates=np.array(statistics["success_rates"]);interval=np.array(statistics["success_ci95"])
    fig,ax=plt.subplots(figsize=(8,4.7),layout="constrained")
    colors=["#4575b4","#ee9b36"]
    for m,model in enumerate(models):
        positions=np.arange(3)+(m-.5)*.34
        bars=ax.bar(positions,100*rates[m],width=.32,color=colors[m],label=model)
        ax.errorbar(positions,100*rates[m],yerr=100*np.maximum(0,np.array([rates[m]-interval[0,m],interval[1,m]-rates[m]])),fmt="none",color="#222",capsize=4)
        ax.bar_label(bars,labels=[f"{int(values[m,:,:,v].sum())}/30" for v in range(3)],padding=5)
    ax.set(xticks=range(3),xticklabels=["Original","Paraphrase 1","Paraphrase 2"],ylim=(0,112),ylabel="Success rate (%)",title="Language robustness: 180 paired rollouts")
    ax.legend();ax.grid(axis="y",alpha=.2)
    fig.savefig(figures/"success_rates.png",dpi=180);plt.close(fig)

    fig,ax=plt.subplots(figsize=(8,9),layout="constrained")
    matrix=values.transpose(1,2,0,3).reshape(30,6)
    ax.imshow(matrix,cmap=ListedColormap(["#c95858","#398c71"]),vmin=0,vmax=1,aspect="auto")
    ax.set(xticks=range(6),xticklabels=["Base\noriginal","Base\nP1","Base\nP2","QLoRA\noriginal","QLoRA\nP1","QLoRA\nP2"],
           yticks=range(30),yticklabels=[f"Task {t} / state {s}" for t in range(3) for s in range(10)],title="Every rollout: green = success, red = failure")
    for line in [9.5,19.5]: ax.axhline(line,color="white",lw=3)
    fig.savefig(figures/"all_rollouts.png",dpi=180);plt.close(fig)

    train=json.loads((HERE.parent/"training_runs/qlora_language_3tasks/summary.json").read_text())
    log=[json.loads(line) for line in (HERE.parent/"training_runs/qlora_language_3tasks/metrics.jsonl").read_text().splitlines()]
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout="constrained")
    x=np.array([r["update"] for r in log]);loss=np.array([r["loss"] for r in log])
    axes[0].plot(x,loss,alpha=.3,color="#4575b4",label="Different training batches")
    axes[0].plot(x[19:],np.convolve(loss,np.ones(20)/20,mode="valid"),color="#244b7d",label="20-update mean")
    axes[0].set(xlabel="Optimizer update",ylabel="Cross-entropy loss",title="Balanced three-task QLoRA");axes[0].legend(fontsize=8)
    for i,stage in enumerate(["before","after"]):
        vals=[train[stage][s]["loss"] for s in ["train","validation"]]
        bars=axes[1].bar(np.arange(2)+(i-.5)*.35,vals,width=.33,label=stage,color=colors[i]);axes[1].bar_label(bars,fmt="%.3f",fontsize=8)
    axes[1].set(xticks=range(2),xticklabels=["Train subset","Validation subset"],ylabel="Loss",title="Fixed 24-frame offline subsets");axes[1].legend()
    fig.savefig(figures/"training.png",dpi=180);plt.close(fig)
    build_index(protocol,results,statistics)
    print(json.dumps(statistics,indent=2))


def build_index(protocol,results,statistics):
    instructions="".join(f"<tr><td>{t['id']}</td><td>{html.escape(v)}</td><td>{html.escape(t[v])}</td></tr>" for t in protocol["tasks"] for v in protocol["variants"])
    cards="".join(f'<section><h3>Task {p["task_id"]} · state {p["state"]} · {p["variant"]}</h3><video controls preload="metadata" src="comparisons/task{p["task_id"]}_comparison.mp4"></video><p>按任务内差异最大的配对选取，仅用于解释；不是随机样本。同步按动作步数播放，完成后保持最后一帧。播放为 0.5× 仿真时间，不是实际推理速度。</p></section>' for p in statistics["selected_video_pairs"])
    rows="".join(f'<tr><td>{model}</td>'+"".join(f'<td>{statistics["success_rates"][m][v]*100:.1f}%</td>' for v in range(3))+f'<td>{statistics["robustness_gap"][m]*100:.1f} pp</td></tr>' for m,model in enumerate(protocol["models"]))
    task_rows="".join(f'<tr><td>Task {t}</td><td>{model}</td>'+"".join(f'<td>{n}/10</td>' for n in statistics['per_task_success_counts'][m][t])+'</tr>' for t in range(3) for m,model in enumerate(protocol['models']))
    gap_change=statistics['gap_change_qlora_minus_base']*100
    gap_interval=[n*100 for n in statistics['gap_change_ci95']]
    interpretation=f'<section><h2>这轮结果怎么理解</h2><p>原始－平均改写的差距变化为 {gap_change:.1f} 个百分点，配对 bootstrap 95% 区间为 [{gap_interval[0]:.1f}, {gap_interval[1]:.1f}] 个百分点。区间跨过零，本轮不能证明这个主指标得到改善，也不能据此证明两个模型等效。</p><p>请同时看下面各任务的结果；总体平均会掩盖局部退步。<a href="先看这些结果.md">实测结果解读与三个视频看点</a></p><table><tr><th>任务</th><th>模型</th><th>原句</th><th>改写 1</th><th>改写 2</th></tr>{task_rows}</table></section>'
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OpenVLA 语言鲁棒性实验</title>
<style>body{font:16px/1.65 system-ui,"Microsoft YaHei",sans-serif;max-width:1200px;margin:35px auto;padding:0 24px;background:#f5f6fa;color:#20283c}h1,h2,h3{line-height:1.3}section,.box{background:white;padding:22px;margin:22px 0;border-radius:12px;border:1px solid #e0e4ee}video{width:100%;max-height:720px;background:#111}img{max-width:100%}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid #ddd;padding:9px;text-align:left}select,button{padding:10px;margin:4px;font:inherit}a{color:#2356a1}p.note{color:#5a6172}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}@media(max-width:800px){.grid{display:block}}</style>
<h1>OpenVLA 语言指令鲁棒性</h1><p>完整实验结果与视频浏览 · 3 个任务 / 3 种表达 / 2 个模型 / 10 个配对初始状态</p>
<div class="box"><b>180/180 回合已完成</b><p>底座和 QLoRA 都使用同样的 NF4 推理设置。微调仅用原始指令。每个回合均保存 720×720 原生渲染视频；模型输入仍为 224×224。</p>
<table><tr><th>模型</th><th>原始指令</th><th>改写 1</th><th>改写 2</th><th>原始－平均改写</th></tr>ROWS</table>
<p class="note">不能仅凭最后一列判断模型更好：原始指令成功率下降也会缩小该差距。下面图中区间为按任务分层、按初始状态配对的 bootstrap 95% 区间。</p></div>
<h2>先看三个对照视频</h2>CARDS
<h2>全部结果</h2><div class="grid"><section><img src="figures/success_rates.png"><p>每个柱子是 30 个回合；区间条件于这三个任务和一次训练。</p></section><section><img src="figures/all_rollouts.png"><p>每行是同一个任务和初始状态，六列是模型与指令条件。</p></section></div>
<h2>浏览任意一个回合</h2><section><select id="model"><option>base</option><option>qlora</option></select><select id="task"><option value="0">Task 0: between</option><option value="1">Task 1: next to</option><option value="2">Task 2: center</option></select><select id="variant"><option>original</option><option>paraphrase_1</option><option>paraphrase_2</option></select><select id="state"></select><p id="description"></p><video id="player" controls preload="metadata"></video><p id="details"></p><p class="note">单回合视频按 20fps 仿真时间播放，不是模型实际推理速度。失败回合也完整保留。</p></section>
<h2>训练与九条固定指令</h2><section><img src="figures/training.png"><p>300 次更新，三个任务各采样 400 帧；训练随机种子为 7。离线指标与闭环成功率分别报告。</p><table><tr><th>任务</th><th>版本</th><th>完整指令</th></tr>INSTRUCTIONS</table></section>
<h2>解释边界</h2><section><p>这是一次探索性实验：一个训练种子、三个相近任务、两种人工改写。底座已被作者在 LIBERO-Spatial 上训练过，不能把本地验证集称为底座从未见过的数据。小样本差异不能直接推广到所有语言表达或机器人任务。</p><p><a href="实验说明与假设.md">实验原理、假设与限制</a> · <a href="statistics.json">统计结果</a> · <a href="all_results.json">180 条结果</a> · <a href="protocol.json">固定实验方案</a> · <a href="../training_runs/qlora_language_3tasks/adapter/adapter_model.safetensors">LoRA 权重</a></p></section>
<script>const results=DATA;const state=document.querySelector('#state');for(let i=0;i<10;i++){let o=document.createElement('option');o.value=i;o.textContent='初始状态 '+i;state.append(o)}function update(){let m=document.querySelector('#model').value,t=+document.querySelector('#task').value,v=document.querySelector('#variant').value,s=+state.value;let r=results.find(x=>x.model===m&&x.task_id===t&&x.variant===v&&x.initial_state_index===s);document.querySelector('#player').src=r.directory+'/video.mp4';document.querySelector('#description').textContent=r.instruction;document.querySelector('#details').textContent=(r.success?'成功':'失败')+' · '+r.steps+' 步 · 平均推理 '+r.mean_inference_seconds.toFixed(3)+' 秒/步';}document.querySelectorAll('select').forEach(x=>x.addEventListener('change',update));update();</script></html>'''
    page=page.replace('ROWS',rows).replace('CARDS',cards).replace('INSTRUCTIONS',instructions).replace('DATA',json.dumps(results,ensure_ascii=False))
    page=page.replace('<h2>先看三个对照视频</h2>',interpretation+'<h2>先看三个对照视频</h2>')
    (HERE/"打开实验结果.html").write_text(page,encoding="utf-8")


if __name__=="__main__":
    main()
