"""Add an internal MP4 to the artifact-tool authored slide 7.

Uses the PresentationML movie shape and timing schema documented at
https://github.com/scanny/python-pptx/blob/master/docs/dev/analysis/shp-movie.rst
No presentation authoring library is used here; existing editable content stays intact.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
from lxml import etree as E

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / (sys.argv[1] if len(sys.argv)>1 else '.build_final/candidate.pptx')
target = ROOT / (sys.argv[2] if len(sys.argv)>2 else '.build_final/candidate_video.pptx')
ns = {'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'p14':'http://schemas.microsoft.com/office/powerpoint/2010/main'}
def add(parent, tag, **attrs):
    prefix, name = tag.split(':')
    return E.SubElement(parent, '{'+ns[prefix]+'}'+name, attrs)
with ZipFile(source) as z:
    files = {name:z.read(name) for name in z.namelist()}
slide = E.fromstring(files['ppt/slides/slide7.xml'])
pic = slide.xpath('.//p:pic', namespaces=ns)
assert len(pic)==1
nv = pic[0].find('p:nvPicPr', ns)
cnv = nv.find('p:cNvPr', ns)
cnv.set('name','Paired simulation video')
link=add(cnv,'a:hlinkClick', action='ppaction://media')
cnv.insert(0,link)
media = nv.find('p:nvPr', ns)
add(media, 'a:videoFile', **{'{'+ns['r']+'}link':'rIdDemoVideo'})
ext = add(add(media,'p:extLst'),'p:ext',uri='{DAA4B4D4-6D71-4841-9C94-3DE7FCFB9230}')
add(ext,'p14:media', **{'{'+ns['r']+'}embed':'rIdDemoMedia'})
assert slide.find('p:timing', ns) is None
root = add(add(add(add(slide,'p:timing'),'p:tnLst'),'p:par'),'p:cTn',id='1',dur='indefinite',restart='never',nodeType='tmRoot')
node = add(add(add(root,'p:childTnLst'),'p:video'),'p:cMediaNode',vol='80000')
tn = add(node,'p:cTn',id='2',fill='hold',display='0')
add(add(tn,'p:stCondLst'),'p:cond',delay='indefinite')
add(add(node,'p:tgtEl'),'p:spTgt',spid=cnv.get('id'))
rels = E.fromstring(files['ppt/slides/_rels/slide7.xml.rels'])
rn = 'http://schemas.openxmlformats.org/package/2006/relationships'
for rid,typ in [('rIdDemoVideo',ns['r']+'/video'),('rIdDemoMedia','http://schemas.microsoft.com/office/2007/relationships/media')]:
    E.SubElement(rels,'{'+rn+'}Relationship',Id=rid,Type=typ,Target='../media/paired_demo.mp4')
types = E.fromstring(files['[Content_Types].xml'])
if not any(x.get('Extension')=='mp4' for x in types):
    E.SubElement(types,'{http://schemas.openxmlformats.org/package/2006/content-types}Default',Extension='mp4',ContentType='video/mp4')
for name,element in [('ppt/slides/slide7.xml',slide),('ppt/slides/_rels/slide7.xml.rels',rels),('[Content_Types].xml',types)]:
    files[name]=E.tostring(element,encoding='UTF-8',xml_declaration=True,standalone=True)
files['ppt/media/paired_demo.mp4']=(ROOT/'language_experiment/comparisons/task1_comparison.mp4').read_bytes()
with ZipFile(target,'w',ZIP_DEFLATED) as z:
    for name,data in files.items():z.writestr(name,data)
print(target)
