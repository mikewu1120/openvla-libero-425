"""Greedy seven-token decoding using the official OpenVLA forward/LLM cache."""
import numpy as np
import torch


@torch.inference_mode()
def predict_batch(model, processor, images, instruction):
    prompt=f"In: What action should the robot take to {instruction.lower()}?\nOut:"
    inputs=processor([prompt]*len(images),images).to("cuda:0",dtype=torch.bfloat16)
    if not torch.all(inputs["input_ids"][:,-1]==29871):
        inputs["input_ids"]=torch.cat([inputs["input_ids"],torch.full((len(images),1),29871,device="cuda",dtype=torch.long)],dim=1)
        # Follow official predict_action: its unchanged mask is handled by generate.
        inputs["attention_mask"]=torch.ones_like(inputs["input_ids"])
    output=model(**inputs,use_cache=True)
    tokens=[]
    for i in range(7):
        token=output.logits[:,-1].argmax(-1)
        if torch.any(token==model.generation_config.eos_token_id):
            raise RuntimeError("Unexpected early EOS; use official single-image inference for this input")
        tokens.append(token)
        if i<6:
            output=model.language_model(input_ids=token[:,None],attention_mask=None,position_ids=None,
                                        past_key_values=output.past_key_values,use_cache=True,return_dict=True)
    ids=torch.stack(tokens,dim=1).cpu().numpy()
    indices=np.clip(model.vocab_size-ids-1,0,len(model.bin_centers)-1)
    normalized=model.bin_centers[indices]
    stats=model.get_action_stats("libero_spatial")
    mask=np.array(stats.get("mask",[True]*7))
    low,high=np.array(stats["q01"]),np.array(stats["q99"])
    return np.where(mask,.5*(normalized+1)*(high-low)+low,normalized)
