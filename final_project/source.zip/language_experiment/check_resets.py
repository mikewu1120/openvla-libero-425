"""Diagnose repeated native simulator resets without loading the policy."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from run_libero_4080 import configure_libero
configure_libero()
from libero.libero import benchmark
from libero.libero.envs import OffScreenRenderEnv
suite=benchmark.get_benchmark_dict()['libero_spatial']()
env=OffScreenRenderEnv(bddl_file_name=suite.get_task_bddl_file_path(0),camera_heights=256,camera_widths=256)
try:
    for index in range(40):
        env.seed(0)
        env.reset()
        env.set_init_state(suite.get_task_init_states(0)[index%10])
        env.sim.render(width=720,height=720,camera_name='agentview')
        print('RESET',index,flush=True)
finally:
    env.close()
