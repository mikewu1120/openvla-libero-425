"""Create three synchronized 2x2 video comparisons from actual saved rollouts."""
import json
import textwrap
from pathlib import Path

import imageio.v2 as imageio
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE=Path(__file__).resolve().parent


def main():
    cases=json.loads((HERE/"selected_comparisons.json").read_text())
    output=HERE/"comparisons";output.mkdir(exist_ok=True)
    title_font=ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf",26)
    font=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",25)
    small=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",21)
    for case in cases:
        directories=[HERE/p for p in case["directories"]]
        results=[json.loads((p/"result.json").read_text()) for p in directories]
        readers=[imageio.get_reader(str(p/"video.mp4")) for p in directories]
        frame_counts=[r["steps"]+1 for r in results]
        cached=[None]*4
        last_indices=[-1]*4
        path=output/f"task{case['task_id']}_comparison.mp4"
        try:
            with imageio.get_writer(str(path),fps=10,codec="libx264",quality=8,macro_block_size=1) as writer:
                for frame_id in range(max(frame_counts)+20):
                    canvas=Image.new("RGB",(1920,1080),(17,23,36))
                    draw=ImageDraw.Draw(canvas)
                    for panel,(reader,result,count) in enumerate(zip(readers,results,frame_counts)):
                        x=(panel%2)*960;y=(panel//2)*540
                        frame_index=min(frame_id,count-1)
                        if frame_index!=last_indices[panel]:
                            cached[panel]=Image.fromarray(reader.get_data(frame_index)).resize((480,480),Image.Resampling.LANCZOS)
                            last_indices[panel]=frame_index
                        canvas.paste(cached[panel],(x,y+60))
                        model="BASE" if result["model"]=="base" else "QLoRA"
                        variant="ORIGINAL" if result["variant"]=="original" else result["variant"].upper().replace("_"," ")
                        draw.text((x+18,y+15),f"{model} | {variant}",font=title_font,fill="white")
                        tx=x+500
                        draw.text((tx,y+74),f"Task {case['task_id']} / Initial state {case['state']}",font=small,fill="#a9b6ca")
                        for line_index,line in enumerate(textwrap.wrap(result["instruction"],width=32)):
                            draw.text((tx,y+122+line_index*34),line,font=font,fill="white")
                        color="#65d4a1" if result["success"] else "#ff8686"
                        outcome="SUCCESS" if result["success"] else "FAILURE"
                        draw.text((tx,y+350),f"Final result: {outcome}",font=title_font,fill=color)
                        draw.text((tx,y+393),f"Step {frame_index} / {result['steps']}",font=font,fill="white")
                        if frame_id>=count:
                            draw.text((tx,y+430),"Finished - holding final frame",font=small,fill="#a9b6ca")
                        draw.text((tx,y+478),"0.5x simulation time; not real time",font=small,fill="#a9b6ca")
                    writer.append_data(np.asarray(canvas))
                    if frame_id==min(40,max(frame_counts)-1):
                        canvas.save(output/f"task{case['task_id']}_preview.png")
        finally:
            for reader in readers: reader.close()
        print("Created",path,flush=True)


if __name__=="__main__":
    main()
