"""Scientific figures for the completed, three-model experiment."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'final_project'/'figures';out.mkdir(parents=True,exist_ok=True)
a=json.loads((ROOT/'improvement/analysis.json').read_text(encoding='utf-8'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
colors=['#2764A5','#C87522','#228569'];names=['Base','Original-only','Augmented']
fig,ax=plt.subplots(figsize=(8,3.3),layout='constrained')
for m in range(3):
    bars=ax.bar(np.arange(3)+(m-1)*.25,np.array(a['rates'][m])*100,.24,label=names[m],color=colors[m])
    ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=10)
ax.set(xticks=np.arange(3),xticklabels=['Original','Paraphrase 1','Paraphrase 2'],ylim=(0,108),ylabel='Success (%)')
ax.legend(ncols=3,loc='upper center',bbox_to_anchor=(.5,1.17),frameon=False)
fig.savefig(out/'success_rates.png',dpi=200);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,2.3),layout='constrained')
centers=[0,a['changes']['qlora']['gap_difference']*100]
intervals=[[-15,16.6666666667],np.array(a['changes']['qlora']['gap_difference_ci95'])*100]
for y,(center,ci) in enumerate(zip(centers,intervals)):
    ax.errorbar(center,y,xerr=[[center-ci[0]],[ci[1]-center]],fmt='o',capsize=5,color=colors[y+1])
ax.axvline(0,color='#777777',linestyle='--',linewidth=1)
ax.set(yticks=[0,1],yticklabels=['Original-only minus base','Augmented minus original-only'],xlabel='Change in robustness gap (percentage points)',ylim=(-.6,1.6),xlim=(-20,20))
fig.savefig(out/'gap_intervals.png',dpi=200);plt.close(fig)
print('Created scientific figures')
