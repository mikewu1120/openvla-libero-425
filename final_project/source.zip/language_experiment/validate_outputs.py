"""Audit saved trajectories, paired initial states, and every encoded video."""
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import imageio.v2 as imageio
import numpy as np

HERE=Path(__file__).resolve().parent
rows=json.loads((HERE/'all_results.json').read_text())
assert len(rows)==180
protocol_hash=hashlib.sha256((HERE/'protocol.json').read_bytes()).hexdigest()
evaluator_hash=hashlib.sha256((HERE/'evaluate.py').read_bytes()).hexdigest()
policy_hash=hashlib.sha256((HERE.parent/'run_libero_4080.py').read_bytes()).hexdigest()
adapter_hash=hashlib.sha256((HERE.parent/'training_runs/qlora_language_3tasks/adapter/adapter_model.safetensors').read_bytes()).hexdigest()
initial_states={}
for row in rows:
    assert row['protocol_sha256']==protocol_hash
    assert row['evaluator_sha256']==evaluator_hash and row['policy_code_sha256']==policy_hash
    assert row['adapter_sha256']==(adapter_hash if row['model']=='qlora' else None)
    key=(row['task_id'],row['initial_state_index'])
    with np.load(HERE/row['directory']/'states.npz') as archive:
        initial=archive['states'][0].copy()
        assert np.isfinite(archive['states']).all()
    if key in initial_states:
        assert np.array_equal(initial_states[key],initial),str(key)
    initial_states[key]=initial

def check_video(job):
    path,size,fps,frames=job
    with imageio.get_reader(str(path)) as reader:
        metadata=reader.get_meta_data()
        assert metadata['size']==size and metadata['fps']==fps,str(path)
        assert reader.count_frames()==frames,str(path)
        assert reader.get_data(frames-1).shape==(size[1],size[0],3)
    return path.stat().st_size

jobs=[(HERE/r['directory']/'video.mp4',(720,720),20,r['steps']+1) for r in rows]
cases=json.loads((HERE/'selected_comparisons.json').read_text())
for case in cases:
    lengths=[json.loads((HERE/p/'result.json').read_text())['steps']+1 for p in case['directories']]
    jobs.append((HERE/'comparisons'/f"task{case['task_id']}_comparison.mp4",(1920,1080),10,max(lengths)+20))
with ThreadPoolExecutor(max_workers=4) as pool:
    sizes=list(pool.map(check_video,jobs))
keys={(r['model'],r['task_id'],r['initial_state_index'],r['variant']):r for r in rows}
changes={}
for variant in ['original','paraphrase_1','paraphrase_2']:
    paired=[(keys[('base',t,s,variant)]['success'],keys[('qlora',t,s,variant)]['success']) for t in range(3) for s in range(10)]
    changes[variant]={'improved':sum(not a and b for a,b in paired),'regressed':sum(a and not b for a,b in paired),'unchanged':sum(a==b for a,b in paired)}
result={'status':'passed','rollouts':180,'exactly_paired_initial_states':30,'videos_checked':len(jobs),'video_bytes':sum(sizes),'model_changes':changes,'protocol_sha256':protocol_hash,'adapter_sha256':adapter_hash}
(HERE/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2),flush=True)
