"""Render post-hoc gain and regression examples from saved simulator videos."""
import json
import textwrap
from pathlib import Path
import imageio.v2 as imageio
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'final_project/demos';OUT.mkdir(exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',25)
bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',26)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',21)
for case in json.loads((ROOT/'improvement/selected_comparisons.json').read_text()):
    dirs=[ROOT/d for d in case['directories']]
    results=[json.loads((d/'result.json').read_text()) for d in dirs]
    readers=[imageio.get_reader(str(d/'video.mp4')) for d in dirs]
    counts=[r['steps']+1 for r in results]
    cached=[None]*4;indices=[-1]*4
    output=OUT/f"augmentation_task{case['task_id']}.mp4"
    try:
        with imageio.get_writer(str(output),fps=10,codec='libx264',quality=8,macro_block_size=1) as writer:
            for frame in range(max(counts)+20):
                canvas=Image.new('RGB',(1920,1080),(17,23,36));draw=ImageDraw.Draw(canvas)
                for i,(reader,r,count) in enumerate(zip(readers,results,counts)):
                    x=i%2*960;y=i//2*540;idx=min(frame,count-1)
                    if idx!=indices[i]:cached[i]=Image.fromarray(reader.get_data(idx)).resize((480,480),Image.Resampling.LANCZOS);indices[i]=idx
                    canvas.paste(cached[i],(x,y+60))
                    model='ORIGINAL-ONLY' if i<2 else 'AUGMENTED'
                    variant=r['variant'].upper().replace('_',' ')
                    draw.text((x+18,y+15),f'{model} | {variant}',font=bold,fill='white')
                    tx=x+500
                    draw.text((tx,y+74),f"Task {case['task_id']} / Initial state {case['state']}",font=small,fill='#a9b6ca')
                    for j,line in enumerate(textwrap.wrap(r['instruction'],32)):draw.text((tx,y+122+j*34),line,font=font,fill='white')
                    outcome='SUCCESS' if r['success'] else 'FAILURE'
                    draw.text((tx,y+350),f'Final result: {outcome}',font=bold,fill='#65d4a1' if r['success'] else '#ff8686')
                    draw.text((tx,y+393),f"Step {idx} / {r['steps']}",font=font,fill='white')
                    if frame>=count:draw.text((tx,y+430),'Finished - holding final frame',font=small,fill='#a9b6ca')
                    draw.text((tx,y+478),'0.5x simulation time; not real time',font=small,fill='#a9b6ca')
                writer.append_data(np.asarray(canvas))
                if frame==40:canvas.save(output.with_suffix('.png'))
    finally:
        for reader in readers:reader.close()
    print(output,flush=True)
