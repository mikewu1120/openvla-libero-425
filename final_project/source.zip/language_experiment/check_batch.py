import json
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from run_libero_4080 import load_model
from language_experiment.batch_policy import predict_batch
import numpy as np
import torch
from PIL import Image

torch.set_num_threads(1)
model,processor=load_model()
protocol=json.loads((ROOT/"language_experiment/protocol.json").read_text())
manifest=json.loads((ROOT/"datasets/language_experiment/manifest.json").read_text())
rows=[]
for task in protocol["tasks"]:
    entry=next(e for e in manifest["episodes"] if e["task_id"]==task["id"])
    data=np.load(ROOT/"datasets/language_experiment"/entry["file"])
    images=[Image.fromarray(data["images"][i]) for i in np.linspace(0,len(data["images"])-1,5,dtype=int)]
    for variant in protocol["variants"]:
        instruction=task[variant]
        reference=[];start=time.perf_counter()
        for image in images:
            inputs=processor(f"In: What action should the robot take to {instruction}?\nOut:",image).to("cuda",dtype=torch.bfloat16)
            with torch.inference_mode(): reference.append(model.predict_action(**inputs,unnorm_key="libero_spatial",do_sample=False))
        serial=time.perf_counter()-start
        torch.cuda.synchronize();start=time.perf_counter()
        batched=predict_batch(model,processor,images,instruction)
        torch.cuda.synchronize();batch_time=time.perf_counter()-start
        row={"task_id":task["id"],"variant":variant,"equal":bool(np.array_equal(reference,batched)),
             "max_difference":float(np.max(np.abs(np.stack(reference)-batched))),"serial_seconds":serial,"batch_seconds":batch_time}
        rows.append(row);print(json.dumps(row),flush=True)
result={"all_equal":all(r["equal"] for r in rows),"tested_images":45,"batch_size":5,"cases":rows,
        "peak_allocated_gib":torch.cuda.max_memory_allocated()/1024**3}
(ROOT/"language_experiment/batch_check.json").write_text(json.dumps(result,indent=2))
