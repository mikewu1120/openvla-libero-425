import fs from 'node:fs/promises';
import path from 'node:path';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const ROOT='C:/Users/15147/Desktop/425';
const BUILD=path.join(ROOT,'.build_final');
const OUT=path.join(ROOT,'final_project');
const base=JSON.parse(await fs.readFile(path.join(ROOT,'language_experiment/statistics.json'),'utf8'));
let extension=null;
try{extension=JSON.parse(await fs.readFile(path.join(ROOT,'improvement/analysis.json'),'utf8'));}catch{}
const p=Presentation.create({slideSize:{width:1280,height:720}});
const C={ink:'#15263B',muted:'#546576',blue:'#2764A5',orange:'#C87522',green:'#228569',paper:'#FFFFFF'};
const FONT='Arial';
const records=[];
const refs={openvla:'https://proceedings.mlr.press/v270/kim25c.html',qlora:'https://papers.neurips.cc/paper_files/paper/2023/hash/1feb87871436031bdc0f2beaa62a049b-Abstract-Conference.html',libero:'https://proceedings.neurips.cc/paper_files/paper/2023/hash/8c3c666820ea055a77726d66fc7d447f-Abstract-Datasets_and_Benchmarks.html'};
function text(s,value,x,y,w,h,size=28,color=C.ink,bold=false,name){const sh=s.shapes.add({geometry:'textbox',name,position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});sh.text=value;sh.text.style={fontFamily:FONT,fontSize:size,color,bold};sh.text.insets=0;return sh;}
function slide(title,en,zh,seconds=45,sources=[]){const s=p.slides.add();s.background.fill=C.paper;text(s,p.slides.items.length===1?'Language Robustness\nin OpenVLA':title,64,42,p.slides.items.length===1?650:1150,p.slides.items.length===1?155:74,p.slides.items.length===1?58:44,C.ink,true,'slide-title');text(s,String(p.slides.items.length),1180,675,35,22,17,C.muted);s.speakerNotes.text=`Target speaking time: ${seconds} seconds\n\nSCRIPT\n${en}\n\nSources\n${sources.join('\n')}`;records.push({slide:p.slides.items.length,title,seconds,english:en,sources});return s;}
async function img(s,file,x,y,w,h,name){const b=await fs.readFile(path.join(ROOT,file));return s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',alt:name??file,name,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function body(s,lines,x=64,y=180,w=1120,size=30,space=95){lines.forEach((v,i)=>text(s,v,x,y+i*space,w,space-12,size));}
function table(s,values,{x=64,y=180,w=1150,h=330,widths}={}){const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:w,height:h,values,columnWidths:widths});t.borders.assign({fill:'#D7DFE6',width:1,style:'solid'});for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){const cell=t.getCell(r,c);cell.fill=r===0?C.ink:(r%2?'#FFFFFF':'#F4F6F8');cell.text.style={fontFamily:FONT,fontSize:26,bold:r===0,color:r===0?'#FFFFFF':C.ink};}return t;}
function chart(s,categories,series,y=180,h=370){return s.charts.add('bar',{position:{left:64,top:y,width:1150,height:h},categories,series,barOptions:{direction:'column',grouping:'clustered',gapWidth:80},hasLegend:true,legend:{position:'bottom',textStyle:{typeface:FONT,fontSize:25}},xAxis:{textStyle:{typeface:FONT,fontSize:25},majorGridlines:null},yAxis:{min:0,max:100,majorUnit:20,numberFormatCode:'0"%"',textStyle:{typeface:FONT,fontSize:21},majorGridlines:{fill:'#DFE5EC',width:1,style:'solid'}},dataLabels:{showValue:true,numberFormatCode:'0.0"%"',position:'outEnd',textStyle:{typeface:FONT,fontSize:23}},chartFill:'#FFFFFF',plotAreaFill:'#FFFFFF'});}

let s=slide('Language Robustness in OpenVLA',
'My project asks whether a robot policy follows the same goal when we change only the wording of its instruction. I study OpenVLA on a twelve gigabyte laptop GPU. The contribution is a controlled local experiment, not a reproduction of the paper’s full benchmark. I compare the pretrained Spatial checkpoint, continuation training with original instructions, and an exploratory training intervention using separate paraphrases.',
'开场说明：研究同一个机器人目标换一种说法后是否仍能完成。贡献是本机可复现的配对实验，不是宣称复现整篇论文。',25,[refs.openvla]);
text(s,'QLoRA on a 12 GB laptop GPU',64,255,600,115,40,C.blue,true);
text(s,'STATS 425 final project\nPaired simulation experiments',64,390,600,110,28,C.muted);
await img(s,'.build_final/cover_scene.png',750,170,460,460,'Local LIBERO simulation');

s=slide('Equivalent instructions, different behavior',
'Both instructions describe the same object and the same destination. A semantic paraphrase should ideally preserve the ability to complete the task. However, the policy generates actions from both images and text. A small action difference changes the next image and can change the entire trajectory. Our experiment therefore measures closed-loop task success, rather than text similarity or a single predicted action. The objects and the initial robot state remain fixed across the paired conditions.',
'两句话目标相同。控制物品和初始状态，只改变语言。动作会改变下一帧观察，因此必须评估完整闭环，而不只比较文本相似度。',45,[refs.openvla,'language_experiment/protocol.json']);
text(s,'Original',64,164,600,40,25,C.blue,true);text(s,'Pick up the black bowl next to the ramekin and place it on the plate.',64,220,650,125,32);
text(s,'Paraphrase',64,380,600,40,25,C.orange,true);text(s,'Find the black bowl next to the ramekin, then move it onto the plate.',64,436,650,130,32);
await img(s,'.build_final/question_scene.png',780,200,420,420,'Paired initial scene');

s=slide('A controlled experiment on limited hardware',
'OpenVLA combines image features and a language model to produce tokenized robot actions. We start from the official checkpoint already fine-tuned on LIBERO-Spatial. To fit the laptop, the base uses four-bit NF4 weights. We freeze it and update only rank-eight adapters in the query and value projections. Each training run has three hundred optimizer updates and the same task-balanced data. The measured peak allocated training memory is about five point five one gibibytes. This is a deliberately small continuation experiment, with a different recipe from the full paper.',
'说明 NF4 冻结底座和 rank 8 适配器。峰值是 PyTorch allocated，不是整个显卡所有进程的占用。不是从零训练，也不是全参数微调。',55,[refs.openvla,refs.qlora,'training_runs/qlora_language_3tasks/summary.json']);
table(s,[['Component','Local configuration'],['Starting model','Official OpenVLA LIBERO-Spatial checkpoint'],['Training data','10 training + 2 validation trajectories per task'],['Update budget','300 updates, batch 1, accumulation 4'],['Adaptation','NF4 base, rank 8, q_proj and v_proj'],['Memory','5.51 GiB peak allocated during original training']],{y:160,h:410,widths:[310,840]});
text(s,'Only 4.19 million adapter parameters are trainable',64,610,1100,42,29,C.blue,true);

s=slide('Paired evaluation design',
'The first study crosses three tasks, three instruction forms, two models, and ten initial states per task, giving one hundred eighty rollouts. Every paired condition starts from the same simulator state, which we verify exactly. A run succeeds only when the environment reports task completion within two hundred twenty actions. The primary robustness gap is original success minus the mean success of the two paraphrases. For uncertainty, we resample initial states within each task, keeping all paired conditions together. This preserves the dependence across instructions and models.',
'180 回合来自 3×3×2×10。每个初始状态下所有条件是配对数据，不应当成独立样本。bootstrap 在任务内重采样初始状态，整组条件一起抽。',50,['language_experiment/protocol.json','language_experiment/validation.json']);
body(s,['3 tasks × 3 wordings × 2 models × 10 states = 180 rollouts','Same initial simulator state for every paired condition','Success within 220 actions, with every failure retained'],64,175,1150,32,90);
text(s,'Robustness gap = original success − mean paraphrase success',64,485,1140,80,33,C.blue,true);
text(s,'5,000 paired bootstrap resamples within the three fixed tasks',64,600,1150,42,26,C.muted);

s=slide('Original-only training improves some success rates',
'On thirty rollouts per condition, original-instruction success increases from seventy-three point three to eighty percent. Paraphrase one increases from fifty to sixty-three point three percent. Paraphrase two remains at sixty percent. But the original-minus-paraphrase gap is eighteen point three percentage points both before and after training. The confidence interval for its change ranges from minus fifteen to plus sixteen point seven points. This study therefore does not establish improvement in the primary robustness metric. Equal aggregate rates also do not imply identical behavior.',
'总体有提升，但主指标差距没有缩小。置信区间跨零不能证明改善，也不能证明两个模型等效。相同平均数可能来自不同回合的改善和退步抵消。',55,['language_experiment/statistics.json']);
chart(s,['Original','Paraphrase 1','Paraphrase 2'],[{name:'Base',values:base.success_rates[0].map(x=>x*100),fill:C.blue},{name:'Original-only QLoRA',values:base.success_rates[1].map(x=>x*100),fill:C.orange}],160,370);
text(s,'Gap change: 0.0 pp   95% paired interval: −15.0 to +16.7 pp',64,565,1140,70,31,C.ink,true);
text(s,'30 rollouts per bar. Rates shown here; paired uncertainty is for the gap change.',64,650,1150,25,20,C.muted);

s=slide('The average hides task-specific regressions',
'The first two tasks improve in total success, but the center-bowl task declines from nineteen to fifteen successes out of thirty. Across the ninety matched conditions, thirteen change from failure to success and seven change from success to failure. For paraphrase two alone there are six improvements and six regressions, leaving its average unchanged. This is why we need both aggregate statistics and paired videos. A smaller gap could also arise because original-instruction performance became worse, so the absolute success rates must remain visible.',
'任务 0、1 提升，任务 2 下降。90 个配对里 13 个改善、7 个退步。改写 2 的平均不变是 6 个改善和 6 个退步抵消，不能说行为没变。',45,['language_experiment/statistics.json','language_experiment/validation.json']);
table(s,[['Task','Base successes','Original-only QLoRA'],['Between','23 / 30','28 / 30'],['Next to','13 / 30','18 / 30'],['Table center','19 / 30','15 / 30']],{y:170,h:290,widths:[420,350,380]});
text(s,'13 improvements, 7 regressions, 70 unchanged paired outcomes',64,525,1150,90,33,C.blue,true);

s=slide('One scene, opposite changes after training',
'The upper row is the base model; the lower row is original-only QLoRA. The left column uses the original instruction, the right a paraphrase. Watch the opposite changes after training. [Play the 24-second video.] This disagreement-selected example illustrates a trade-off; it does not estimate its frequency. Playback is slowed simulation time.',
'播放约 24 秒。上排底座、下排微调，左列原句、右列改写。强调两个方向的变化，同时说明案例按差异挑选，频率要看总体统计。',45,['language_experiment/selected_comparisons.json']);
await img(s,'language_experiment/comparisons/task1_preview.png',155,125,970,546,'demo-poster');

s=slide('Exploratory intervention: language augmentation',
'The observed sensitivity motivates a targeted intervention. Instead of changing the images or increasing training time, we cycle between the original instruction and two additional training paraphrases. These training sentences are different from the evaluation sentences. The model starts again from the same official checkpoint with the same seed, images, task balance and three hundred updates. We then evaluate another ninety rollouts on the existing cases. Because we designed this intervention after inspecting the initial results, it is exploratory and reuses the test set. It is not an independent confirmation.',
'新增实验只改训练文本，预算、底座、图像和种子相同。训练的两句改写与测试句不同，但复用了测试场景，因此必须标为探索性，不能宣称独立验证。',50,['improvement/protocol.json','improvement/train_augmented.py']);
body(s,['Same checkpoint, images, seed and 300-update budget','Cycle original wording + two separate training paraphrases','Evaluate the same 90 conditions with a third model'],64,170,1150,32,95);
text(s,'Training example',64,485,400,40,24,C.green,true);
text(s,'Grasp the black bowl next to the ramekin and set it on the plate.',64,535,1100,75,30);
text(s,'Exploratory follow-up designed after inspecting the initial experiment',64,650,1150,30,22,C.muted);

s=slide('Augmentation results',
extension?.narrative_en??'The augmented evaluation is still running. This private draft will be replaced with the measured results before delivery.',
extension?.narrative_zh??'等待实际结果，不用占位数字做结论。',50,['improvement/analysis.json']);
if(extension){chart(s,['Original','Paraphrase 1','Paraphrase 2'],extension.rates.map((v,i)=>({name:['Base','Original-only','Augmented'][i],values:v.map(x=>x*100),fill:[C.blue,C.orange,C.green][i]})),155,390);text(s,extension.slide_takeaway,64,570,1145,80,30,C.ink,true);text(s,'Exploratory reused cases, one training seed. 30 rollouts per condition.',64,650,1150,27,22,C.muted);}else body(s,['Evaluation in progress','Final slides will contain only measured results'],64,220,1100,36,100);

s=slide('What this project establishes',
'This project establishes that a small, quantized OpenVLA continuation experiment can run on the available laptop, with reproducible paired trajectories and videos. It also shows that equivalent wording can change closed-loop outcomes. Improvements in offline loss or average task success do not by themselves establish language robustness. The next confirmatory study should fix the intervention first, use new paraphrases and initial states, repeat training across seeds, and include a same-scene different-target control. That final control tests whether the policy actually needs the language, rather than exploiting visual regularities.',
'结论分清已证实与待验证。已证实本机可跑、措辞会改变闭环结果；未证实广泛泛化或真正语言理解。下一轮需要新测试句、新状态、多训练种子，以及同场景换目标的语言必要性对照。',40,[refs.openvla,'language_experiment/protocol.json','improvement/protocol.json']);
body(s,['Equivalent wording can change closed-loop outcomes','Average success and language robustness measure different things','Confirm with new cases, multiple seeds and target-change controls'],64,190,1140,33,115);
text(s,'A reproducible experiment with visible successes and failures',64,595,1150,55,32,C.blue,true);

s=slide('Appendix: full task-level counts','Use this table for questions about which task drives the result. Every cell has ten rollouts. These are counts, not percentages.','备用页：每格分母是 10。按任务展开所有结果，避免只讲平均。',0,['language_experiment/statistics.json','improvement/analysis.json']);
const tv=[['Task / model','Original','P1','P2']];for(let t=0;t<3;t++)for(let m=0;m<(extension?3:2);m++)tv.push([`${['Between','Next to','Center'][t]} / ${['Base','Original','Augmented'][m]}`,...(extension?extension.counts[m][t]:base.per_task_success_counts[m][t]).map(n=>`${n}/10`)]);
table(s,tv,{y:145,h:490,widths:[590,190,190,180]});

s=slide('Appendix: inference and reproducibility','The intervals condition on the three selected tasks and one training seed. Each bootstrap draw keeps all model and instruction outcomes for a sampled initial state together. This is not a broad confidence statement over unseen robot tasks. The saved experiment contains protocol hashes, adapter hashes, actions, simulator states, high-resolution videos and executable analysis scripts. The official starting checkpoint had already seen LIBERO-Spatial.','备用页：配对 bootstrap 的抽样单位和不确定性边界。底座已在 Spatial 上训练过，不把本地验证集说成底座从没见过。',0,['language_experiment/validation.json','language_experiment/provenance.json']);
body(s,['Resample initial states within each fixed task','Keep every model and wording together in each sampled group','One training seed, three related tasks, two evaluation paraphrases','Saved hashes, actions, states, videos and analysis code'],64,165,1150,29,100);

s=slide('Appendix: sources','The supplied OpenVLA paper is the starting point. The study uses the official code and model rather than claiming to retrain the full model. LIBERO provides the simulation tasks and demonstrations. QLoRA motivates the quantized low-rank adaptation, while our restricted query/value recipe is explicitly a local configuration.','文献页。OpenVLA 使用论文和官方实现；LIBERO 提供任务；QLoRA 提供量化低秩微调的基础。',0,Object.values(refs));
body(s,['Kim et al.  OpenVLA.  CoRL, PMLR 270, 2025','Liu et al.  LIBERO.  NeurIPS Datasets and Benchmarks, 2023','Dettmers et al.  QLoRA.  NeurIPS, 2023','Official code and checkpoint revisions are recorded in provenance.json'],64,175,1150,30,105);

await fs.mkdir(path.join(BUILD,'renders'),{recursive:true});
for(const [i,sl] of p.slides.items.entries()){const png=await p.export({slide:sl,format:'png',scale:1});await fs.writeFile(path.join(BUILD,'renders',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));}
await (await PresentationFile.exportPptx(p)).save(path.join(BUILD,'candidate.pptx'));
await fs.writeFile(path.join(BUILD,'speaker_notes.json'),JSON.stringify(records,null,2));
console.log(JSON.stringify({slides:p.slides.items.length,main_seconds:records.slice(0,10).reduce((n,r)=>n+r.seconds,0),extension_included:!!extension}));
